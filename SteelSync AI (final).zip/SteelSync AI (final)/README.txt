Step 1:
-------
Open command prompt and select the backend folder of this page.

U must download npm packages for this to work.

use the command in the command prompt to start the backend-

     "npm start"

The login user details with the permission levels are displayed in the third line after command has been commanded .

Step 2:
-------

Finally open the website using the login page html code in the frontend folder and login using the credentials shown while starting the backend. 

