/**
 * SteelSync AI Common Utilities v2 — Live Database Edition
 * All pages import this for API calls, session management, and shared helpers.
 */

const API_BASE = 'http://localhost:5000';

// ── Session ───────────────────────────────────────────────────

function getUserLevel()    { return parseInt(localStorage.getItem('userlevel')) || 0; }
function getUsername()     { return localStorage.getItem('username') || ''; }
function getUserRole()     { return localStorage.getItem('userrole') || ''; }
function hasLevel(minLvl)  { return getUserLevel() >= minLvl; }

async function checkSession() {
  try {
    const data = await apiFetch('/auth/me');
    if (!data.loggedIn) throw new Error('Not logged in');
    // Sync localStorage with server session
    localStorage.setItem('userlevel',  data.level);
    localStorage.setItem('username',   data.username);
    localStorage.setItem('userrole',   data.role);
    return data;
  } catch {
    localStorage.clear();
    if (!window.location.pathname.includes('1_login')) {
      window.location.href = '1_login.html';
    }
    return null;
  }
}

// ── API Fetch ─────────────────────────────────────────────────

async function apiFetch(endpoint, options = {}) {
  const level    = localStorage.getItem('userlevel') || '';
  const username = localStorage.getItem('username')  || '';

  const defaults = {
    credentials: 'include',
    headers: {
      'Content-Type': 'application/json',
      'X-User':  username,
      'X-Level': level
    }
  };

  const merged = {
    ...defaults,
    ...options,
    headers: { ...defaults.headers, ...(options.headers || {}) }
  };

  const res = await fetch(`${API_BASE}${endpoint}`, merged);

  if (res.status === 401 || res.status === 403) {
    localStorage.clear();
    window.location.href = '1_login.html';
    throw new Error('Session expired');
  }
  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: res.statusText }));
    throw new Error(err.error || res.statusText);
  }
  return res.json();
}

// ── Toast notifications ───────────────────────────────────────

function toast(msg, type = '') {
  let wrap = document.getElementById('toasts');
  if (!wrap) {
    wrap = document.createElement('div');
    wrap.id = 'toasts';
    wrap.style.cssText = 'position:fixed;bottom:20px;right:20px;display:flex;flex-direction:column;gap:8px;z-index:9999;pointer-events:none;';
    document.body.appendChild(wrap);
  }
  const t = document.createElement('div');
  t.style.cssText = `padding:12px 16px;border-left:3px solid ${type==='ok'?'#6fcf97':type==='error'?'#ff6b6b':'#96ccff'};background:#1e2022;color:#e2e2e5;font-size:12px;max-width:320px;border-radius:1px;opacity:0;transform:translateY(8px);transition:all .3s;border-top:1px solid #333537;border-right:1px solid #333537;border-bottom:1px solid #333537;font-family:'Space Grotesk',sans-serif;`;
  t.textContent = msg;
  wrap.appendChild(t);
  requestAnimationFrame(() => { t.style.opacity = '1'; t.style.transform = 'translateY(0)'; });
  setTimeout(() => { t.style.opacity='0'; setTimeout(() => t.remove(), 400); }, 4000);
}

// ── Inventory helpers ─────────────────────────────────────────

async function fetchInventory()  { return apiFetch('/inventory'); }
async function fetchOrders(q='') { return apiFetch('/orders' + (q ? '?'+q : '')); }

function stockColor(pct) {
  return pct > 50 ? '#6fcf97' : pct > 20 ? '#f2c94c' : '#ffb692';
}
function stockLabel(status) {
  return { healthy: 'Healthy', low: 'Low Stock', critical: 'Critical', empty: 'Empty' }[status] || 'Unknown';
}
function stockTagStyle(status) {
  if (status === 'healthy') return 'background:#0d3320;color:#6fcf97;border:1px solid #6fcf97;';
  if (status === 'low')     return 'background:#1a2500;color:#f2c94c;border:1px solid #f2c94c;';
  return 'background:#562000;color:#ffb692;border:1px solid #ffb692;';
}

// ── Render level-based UI ─────────────────────────────────────

function applyLevelUI() {
  const level = getUserLevel();
  // Hide elements marked for higher levels
  document.querySelectorAll('[data-min-level]').forEach(el => {
    const min = parseInt(el.dataset.minLevel);
    el.style.display = level >= min ? '' : 'none';
  });
  // Update sidebar user badge
  const badge = document.getElementById('userBadge');
  if (badge) {
    badge.textContent = `${getUsername().toUpperCase()} · LEVEL ${level}`;
  }
}

// ── Clock ─────────────────────────────────────────────────────

function startClock(id = 'clock') {
  function tick() {
    const el = document.getElementById(id);
    if (el) el.textContent = new Date().toLocaleTimeString('en-IN', { hour12: false });
  }
  tick();
  return setInterval(tick, 1000);
}

// ── Export ────────────────────────────────────────────────────

window.NexusUtils = {
  getUserLevel, getUsername, getUserRole, hasLevel,
  checkSession, apiFetch, toast,
  fetchInventory, fetchOrders,
  stockColor, stockLabel, stockTagStyle,
  applyLevelUI, startClock,
  API_BASE
};
