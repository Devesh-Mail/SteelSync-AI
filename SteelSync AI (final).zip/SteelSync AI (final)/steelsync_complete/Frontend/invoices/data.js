const invoices = [
  {
    id: "ABC-OCT22-001",
    status: "paid",
    type: "modern", // Used for ABC Company style
    company: "ABC Company",
    date: "12 October, 2022",
    billTo: "Liceria & Co.\n123 Anywhere St.,\nAny City, ST 12345\nTel: +123-456-7890\nEmail: customer email id",
    items: [
      { description: "Logo Design", qty: 5, price: 2000, amount: 10000 },
      { description: "Advertising Design", qty: 10, price: 500, amount: 5000 },
      { description: "Poster Design", qty: 5, price: 1000, amount: 5000 },
      { description: "Brochure Design", qty: 1, price: 2000, amount: 2000 }
    ],
    subtotal: 22000,
    taxRate: "10%",
    total: 24200,
    currency: "₹",
    bankName: "Olivia Wilson",
    bankAccount: "0123 4567 8901",
    terms: "Payment terms, such as 'Payment due within 30 days'"
  },
  {
    id: "INV-2026-001",
    status: "pending",
    type: "industrial", // Used for SteelCorp style
    company: "SteelCorp Pvt Ltd, Mumbai, India",
    buyer: "ABC Steel Plant, Chennai, India",
    date: "17-Mar-2026",
    poNo: "PO-45892",
    items: [
      { description: "Steel Coils - Grade A", qty: 500, price: 700, amount: 350000 }
    ],
    qtyUnit: "MT",
    priceUnit: "$",
    subtotal: 350000,
    freight: 20000,
    taxName: "GST 18%",
    taxAmount: 66600,
    total: 436600,
    currency: "$",
    terms: "Net 30 days | Mode: Bank Transfer"
  },
  {
    id: "ABC-NOV22-045",
    status: "pending",
    type: "modern",
    company: "ABC Company",
    date: "05 November, 2022",
    billTo: "Design Studio Inc.\n456 Web Ave,\nTech City, ST 98765\nTel: +198-765-4321",
    items: [
      { description: "UI Refresh", qty: 1, price: 15000, amount: 15000 },
      { description: "Brand Revisions", qty: 2, price: 3000, amount: 6000 }
    ],
    subtotal: 21000,
    taxRate: "10%",
    total: 23100,
    currency: "₹",
    bankName: "Olivia Wilson",
    bankAccount: "0123 4567 8901",
    terms: "Payment due within 15 days"
  },
  {
    id: "INV-2026-089",
    status: "paid",
    type: "industrial",
    company: "SteelCorp Pvt Ltd, Mumbai, India",
    buyer: "Global Manufacturing, Delhi, India",
    date: "02-Feb-2026",
    poNo: "PO-42110",
    items: [
      { description: "Iron Ore Pellets", qty: 1200, price: 150, amount: 180000 },
      { description: "Scrap Metal", qty: 300, price: 200, amount: 60000 }
    ],
    qtyUnit: "MT",
    priceUnit: "$",
    subtotal: 240000,
    freight: 15000,
    taxName: "GST 18%",
    taxAmount: 43200,
    total: 298200,
    currency: "$",
    terms: "Net 15 days | Mode: Bank Transfer"
  }
];

if (typeof module !== 'undefined' && module.exports) {
  module.exports = invoices;
}
