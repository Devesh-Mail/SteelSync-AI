// ===============================
// AI SUPPLY CHAIN SIMULATION ENGINE
// ===============================

// INVENTORY DATA (SIMULATED)
const inventoryData = [
    {
        material: "Iron Ore",
        stock: 6300,
        capacity: 10000,
        dailyUsage: 2500
    },
    {
        material: "Coal",
        stock: 4200,
        capacity: 9000,
        dailyUsage: 1800
    },
    {
        material: "Limestone",
        stock: 3000,
        capacity: 7000,
        dailyUsage: 900
    }
]

// ROUTE COST DATA
const routeData = [
    { route: "Route A", cost: 200000 },
    { route: "Route B", cost: 150000 },
    { route: "Route C", cost: 170000 }
]

// ===============================
// INVENTORY RISK PREDICTION
// ===============================

function predictInventoryRisk() {

    const results = []

    inventoryData.forEach(item => {

        const daysRemaining = item.stock / item.dailyUsage

        let riskLevel = "LOW"

        if (daysRemaining < 3) riskLevel = "CRITICAL"
        else if (daysRemaining < 5) riskLevel = "MEDIUM"

        results.push({
            material: item.material,
            daysRemaining: daysRemaining.toFixed(1),
            risk: riskLevel,
            suggestedOrder: item.dailyUsage * 2
        })

    })

    return results
}


// ===============================
// SHUTDOWN PREDICTOR
// ===============================

function predictPlantShutdown() {

    const risks = predictInventoryRisk()

    let highestRisk = 0

    risks.forEach(r => {

        if (r.risk === "CRITICAL") highestRisk += 40
        if (r.risk === "MEDIUM") highestRisk += 20

    })

    if (highestRisk > 100) highestRisk = 100

    return {
        riskPercent: highestRisk
    }
}


// ===============================
// COST OPTIMIZER
// ===============================

function optimizeRoute() {

    let best = routeData[0]

    routeData.forEach(route => {

        if (route.cost < best.cost) best = route

    })

    const worst = routeData.reduce((a,b)=> a.cost > b.cost ? a : b)

    const savings = worst.cost - best.cost

    return {
        bestRoute: best.route,
        cost: best.cost,
        savings: savings
    }
}


// ===============================
// UPDATE RISK ALERT PAGE
// ===============================

function renderRiskAlerts() {

    const results = predictInventoryRisk()

    const container = document.getElementById("riskContainer")

    if(!container) return

    container.innerHTML = ""

    results.forEach(r => {

        const card = document.createElement("div")

        card.innerHTML = `
        <h3>${r.material}</h3>
        <p>Days Remaining: ${r.daysRemaining}</p>
        <p>Risk Level: ${r.risk}</p>
        <p>Suggested Order: ${r.suggestedOrder} tons</p>
        <hr>
        `

        container.appendChild(card)

    })

}


// ===============================
// UPDATE COST DASHBOARD
// ===============================

function renderCostDashboard() {

    const result = optimizeRoute()

    const container = document.getElementById("costContainer")

    if(!container) return

    container.innerHTML = `
        <h2>Best Route: ${result.bestRoute}</h2>
        <p>Cost: $${result.cost}</p>
        <p>AI Savings: $${result.savings}</p>
    `
}


// ===============================
// UPDATE SHUTDOWN PREDICTOR
// ===============================

function renderShutdownPrediction() {

    const result = predictPlantShutdown()

    const container = document.getElementById("shutdownContainer")

    if(!container) return

    container.innerHTML = `
        <h2>Plant Downtime Risk</h2>
        <h1>${result.riskPercent}%</h1>
    `
}


// ===============================
// AUTO RUN ON PAGE LOAD
// ===============================

window.onload = function(){

    renderRiskAlerts()
    renderCostDashboard()
    renderShutdownPrediction()

}