/**
 * NexusOps Security Middleware
 * ─────────────────────────────
 * In-memory rate limiter, input sanitizer, and security headers.
 * No external dependencies required.
 */

// ── In-memory rate limiter ────────────────────────────────────
const rateBuckets = new Map();

/**
 * createRateLimiter(maxReq, windowMs)
 * Returns middleware that allows maxReq requests per windowMs per IP.
 */
function createRateLimiter(maxReq = 30, windowMs = 60000) {
  return function rateLimiter(req, res, next) {
    const ip  = req.ip || req.socket.remoteAddress || 'unknown';
    const now = Date.now();
    let bucket = rateBuckets.get(ip);

    if (!bucket || now - bucket.start > windowMs) {
      bucket = { start: now, count: 1 };
    } else {
      bucket.count++;
    }
    rateBuckets.set(ip, bucket);

    if (bucket.count > maxReq) {
      return res.status(429).json({
        error: 'Too many requests. Please slow down.',
        retryAfter: Math.ceil((bucket.start + windowMs - now) / 1000)
      });
    }
    next();
  };
}

// Cleanup old buckets every 5 minutes
setInterval(() => {
  const cutoff = Date.now() - 120000;
  for (const [ip, b] of rateBuckets) {
    if (b.start < cutoff) rateBuckets.delete(ip);
  }
}, 300000);

// ── Security headers ──────────────────────────────────────────
function securityHeaders(req, res, next) {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('X-XSS-Protection', '1; mode=block');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate');
  next();
}

// ── Input sanitizer ───────────────────────────────────────────
function sanitizeString(str, maxLen = 200) {
  if (typeof str !== 'string') return '';
  return str.replace(/[<>'"`;]/g, '').substring(0, maxLen).trim();
}

function sanitizeBody(req, res, next) {
  if (req.body && typeof req.body === 'object') {
    for (const key of Object.keys(req.body)) {
      if (typeof req.body[key] === 'string') {
        req.body[key] = sanitizeString(req.body[key]);
      }
    }
  }
  next();
}

// ── Auth middleware ───────────────────────────────────────────
function requireLevel(min) {
  return function(req, res, next) {
    const user = req.session && req.session.user;
    if (!user || user.level < min) {
      return res.status(403).json({ error: 'Insufficient permissions', required: min, current: user ? user.level : 0 });
    }
    next();
  };
}

// Login attempt tracker
const loginAttempts = new Map();

function trackLoginAttempt(ip, success) {
  const now = Date.now();
  let rec = loginAttempts.get(ip) || { count: 0, lockUntil: 0 };
  if (success) {
    loginAttempts.delete(ip);
    return { locked: false };
  }
  if (now < rec.lockUntil) {
    return { locked: true, seconds: Math.ceil((rec.lockUntil - now) / 1000) };
  }
  rec.count++;
  if (rec.count >= 5) {
    rec.lockUntil = now + 5 * 60 * 1000; // 5-min lockout
    rec.count = 0;
  }
  loginAttempts.set(ip, rec);
  return { locked: false, attempts: rec.count };
}

function isLoginLocked(ip) {
  const rec = loginAttempts.get(ip);
  if (!rec) return false;
  if (Date.now() < rec.lockUntil) return Math.ceil((rec.lockUntil - Date.now()) / 1000);
  return false;
}

module.exports = {
  createRateLimiter,
  securityHeaders,
  sanitizeBody,
  sanitizeString,
  requireLevel,
  trackLoginAttempt,
  isLoginLocked
};
