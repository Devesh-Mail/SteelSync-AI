/**
 * NexusOps Secure Database Engine
 * ─────────────────────────────────────────────────────────────
 * Provides atomic read/write, salted SHA-256 password hashing,
 * structured tables for inventory, orders, users, audit_log,
 * and auto-order config. Replaces raw JSON files with a
 * proper transactional layer.
 */

const fs     = require('fs');
const path   = require('path');
const crypto = require('crypto');

const DB_DIR  = path.join(__dirname, '../data/db');
const LOCK_MS = 200; // simple file-lock timeout

// ── Ensure DB directory exists ────────────────────────────────
if (!fs.existsSync(DB_DIR)) fs.mkdirSync(DB_DIR, { recursive: true });

// ── Tables ────────────────────────────────────────────────────
const TABLES = {
  users:              path.join(DB_DIR, 'users.json'),
  inventory:          path.join(DB_DIR, 'inventory.json'),
  orders:             path.join(DB_DIR, 'orders.json'),
  audit_log:          path.join(DB_DIR, 'audit_log.json'),
  auto_order:         path.join(DB_DIR, 'auto_order.json'),
  consumption_rates:  path.join(DB_DIR, 'consumption_rates.json'),
};

// ── Crypto helpers ────────────────────────────────────────────

/**
 * Hash a password with a random salt using PBKDF2 (100k iterations).
 * Returns "salt:hash" string.
 */
function hashPassword(plain) {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.pbkdf2Sync(plain, salt, 100000, 64, 'sha512').toString('hex');
  return `${salt}:${hash}`;
}

/**
 * Verify a plain password against a stored "salt:hash" or legacy SHA-256 hash.
 */
function verifyPassword(plain, stored) {
  if (!stored) return false;
  if (stored.includes(':')) {
    // PBKDF2 format
    const [salt, hash] = stored.split(':');
    const check = crypto.pbkdf2Sync(plain, salt, 100000, 64, 'sha512').toString('hex');
    return crypto.timingSafeEqual(Buffer.from(hash, 'hex'), Buffer.from(check, 'hex'));
  }
  // Legacy SHA-256 (migration path)
  const legacy = crypto.createHash('sha256').update(plain).digest('hex');
  return legacy === stored;
}

// ── Atomic read / write ───────────────────────────────────────

function readTable(table) {
  const file = TABLES[table];
  if (!file) throw new Error(`Unknown table: ${table}`);
  try {
    return JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch {
    return [];
  }
}

function writeTable(table, data) {
  const file = TABLES[table];
  if (!file) throw new Error(`Unknown table: ${table}`);
  const tmp = file + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(data, null, 2), 'utf8');
  fs.renameSync(tmp, file); // atomic on same filesystem
}

// ── Audit log ─────────────────────────────────────────────────

function auditLog(username, action, details = {}) {
  try {
    const log = readTable('audit_log');
    log.unshift({
      ts: new Date().toISOString(),
      username,
      action,
      details
    });
    // Keep last 2000 entries
    writeTable('audit_log', log.slice(0, 2000));
  } catch { /* non-critical */ }
}

// ── Users ─────────────────────────────────────────────────────

function initUsers(legacyUsersPath) {
  const file = TABLES.users;
  if (fs.existsSync(file)) return; // already initialised

  let source = [];
  try {
    const raw  = JSON.parse(fs.readFileSync(legacyUsersPath, 'utf8'));
    source = raw.users || [];
  } catch { source = []; }

  // Migrate existing users — re-hash with PBKDF2
  const migrated = source.map(u => {
    const passwords = { admin: 'enter', op: 'op123', user: 'user123' };
    const plain = passwords[u.username];
    return {
      id:           u.id,
      username:     u.username,
      passwordHash: plain ? hashPassword(plain) : hashPassword(crypto.randomBytes(12).toString('hex')),
      level:        u.level,
      role:         u.role,
      fullName:     u.fullName || u.username,
      email:        u.email || '',
      createdAt:    u.createdAt || new Date().toISOString(),
      lastLogin:    u.lastLogin || null,
      active:       u.active !== false
    };
  });

  if (!migrated.length) {
    // Bootstrap default admin
    migrated.push({
      id: 1, username: 'admin', passwordHash: hashPassword('enter'),
      level: 3, role: 'Admin', fullName: 'System Administrator',
      email: 'admin@nexusops.local',
      createdAt: new Date().toISOString(), lastLogin: null, active: true
    });
  }

  writeTable('users', migrated);
  console.log(`[DB] Users table initialised with ${migrated.length} user(s).`);
}

function getUser(username) {
  const rows = readTable('users');
  return rows.find(u => u.username === username && u.active) || null;
}

function loginUser(username, password) {
  const user = getUser(username);
  if (!user) return null;
  if (!verifyPassword(password, user.passwordHash)) return null;

  // Update lastLogin
  const rows = readTable('users');
  const idx  = rows.findIndex(u => u.id === user.id);
  if (idx !== -1) {
    rows[idx].lastLogin = new Date().toISOString();
    writeTable('users', rows);
  }

  const { passwordHash, ...safe } = user;
  return safe;
}

function getAllUsers() {
  return readTable('users')
    .filter(u => u.active)
    .map(({ passwordHash, ...u }) => u);
}

function getUserById(id) {
  const rows = readTable('users');
  const user = rows.find(u => u.id === id);
  if (!user) return null;
  const { passwordHash, ...safe } = user;
  return safe;
}

function createUser({ username, password, level, role, fullName, email }) {
  const rows = readTable('users');
  if (rows.find(u => u.username === username)) {
    throw new Error(`Username "${username}" already exists`);
  }
  const maxId = rows.reduce((m, u) => Math.max(m, u.id), 0);
  const lvl   = Number(level) || 1;
  const newUser = {
    id:           maxId + 1,
    username,
    passwordHash: hashPassword(password),
    level:        lvl,
    role:         role || (lvl === 3 ? 'Admin' : lvl === 2 ? 'Operator' : 'Read-Only'),
    fullName:     fullName || username,
    email:        email || '',
    createdAt:    new Date().toISOString(),
    lastLogin:    null,
    active:       true
  };
  rows.push(newUser);
  writeTable('users', rows);
  auditLog('system', 'user_created', { username });
  const { passwordHash, ...safe } = newUser;
  return safe;
}

function updateUser(id, fields) {
  const rows = readTable('users');
  const idx  = rows.findIndex(u => u.id === id);
  if (idx === -1) throw new Error('User not found');
  if (fields.password) {
    rows[idx].passwordHash = hashPassword(fields.password);
    delete fields.password;
  }
  Object.assign(rows[idx], fields);
  writeTable('users', rows);
  auditLog('system', 'user_updated', { id });
  const { passwordHash, ...safe } = rows[idx];
  return safe;
}

function deleteUser(id) {
  const rows = readTable('users');
  const idx  = rows.findIndex(u => u.id === id);
  if (idx === -1) throw new Error('User not found');
  if (rows[idx].username === 'admin') throw new Error('Cannot delete the admin account');
  rows[idx].active = false;
  writeTable('users', rows);
  auditLog('system', 'user_deleted', { id });
  return { success: true };
}

// ── Inventory ─────────────────────────────────────────────────

function initInventory(legacyPath) {
  const file = TABLES.inventory;
  if (fs.existsSync(file)) return;

  let source = [];
  try { source = JSON.parse(fs.readFileSync(legacyPath, 'utf8')); } catch {}

  if (!source.length) {
    source = [
      { id:'SKU-1001', material:'Iron Ore Pellets',         stock:8000, maxStock:10000, dailyUsage:250,  reorderThreshold:2000, unit:'tons',  supplierCity:'Mumbai',     supplierName:'Tata Steel',          costPerUnit:3200 },
      { id:'SKU-1002', material:'Coking Coal',              stock:6500, maxStock:8000,  dailyUsage:180,  reorderThreshold:1500, unit:'tons',  supplierCity:'Jamshedpur', supplierName:'JSW Steel',           costPerUnit:1800 },
      { id:'SKU-1003', material:'Limestone Fines',          stock:4200, maxStock:5000,  dailyUsage:90,   reorderThreshold:800,  unit:'tons',  supplierCity:'Bengaluru',  supplierName:'RockQuarry Ltd',      costPerUnit:900  },
      { id:'SKU-1004', material:'Grade-4 Titanium Castings',stock:750,  maxStock:1000,  dailyUsage:45,   reorderThreshold:200,  unit:'kg',    supplierCity:'Coimbatore', supplierName:'TitanForge',          costPerUnit:12000},
      { id:'SKU-1005', material:'Synthetic Lubricant Blend',stock:980,  maxStock:1200,  dailyUsage:25,   reorderThreshold:240,  unit:'L',     supplierCity:'Chennai',    supplierName:'Castrol Industrial',  costPerUnit:450  },
      { id:'SKU-1006', material:'Control Board Arrays',     stock:380,  maxStock:500,   dailyUsage:12,   reorderThreshold:100,  unit:'units', supplierCity:'Hyderabad',  supplierName:'ElecTech Solutions',  costPerUnit:8500 },
    ];
  }

  const clean = source.map(item => ({
    id:                item.id,
    material:          item.material,
    stock:             Math.max(0, Number(item.stock) || 0),
    maxStock:          item.maxStock,
    dailyUsage:        item.dailyUsage,
    reorderThreshold:  item.reorderThreshold,
    unit:              item.unit,
    supplierCity:      item.supplierCity   || '',
    supplierName:      item.supplierName   || '',
    costPerUnit:       item.costPerUnit    || 0,
    lastUpdated:       new Date().toISOString()
  }));

  writeTable('inventory', clean);
  console.log(`[DB] Inventory table initialised with ${clean.length} SKU(s).`);
}

function getInventory() {
  const rows = readTable('inventory');
  return rows.map(item => ({
    ...item,
    stock:    Math.max(0, item.stock),
    daysLeft: item.dailyUsage > 0 ? Math.max(0, +(item.stock / item.dailyUsage).toFixed(1)) : 0,
    pctStock: +((item.stock / item.maxStock) * 100).toFixed(1),
    riskPct:  item.stock < item.reorderThreshold
              ? +((item.reorderThreshold - item.stock) / item.reorderThreshold * 100).toFixed(1)
              : 0,
    status:   item.stock <= 0 ? 'empty'
              : item.stock < item.reorderThreshold ? 'critical'
              : item.stock < item.reorderThreshold * 1.5 ? 'low'
              : 'healthy'
  }));
}

function updateStock(id, delta, username = 'system') {
  const rows = readTable('inventory');
  const idx  = rows.findIndex(i => i.id === id);
  if (idx === -1) return null;
  const before = rows[idx].stock;
  rows[idx].stock = Math.max(0, rows[idx].stock + delta);
  rows[idx].lastUpdated = new Date().toISOString();
  writeTable('inventory', rows);
  auditLog(username, 'stock_update', { id, before, after: rows[idx].stock, delta });
  return rows[idx];
}

function setStock(id, value, username = 'system') {
  const rows = readTable('inventory');
  const idx  = rows.findIndex(i => i.id === id);
  if (idx === -1) return null;
  const before = rows[idx].stock;
  rows[idx].stock = Math.max(0, value);
  rows[idx].lastUpdated = new Date().toISOString();
  writeTable('inventory', rows);
  auditLog(username, 'stock_set', { id, before, after: rows[idx].stock });
  return rows[idx];
}

function depleteInventory(seconds = 60) {
  const rows = readTable('inventory');
  rows.forEach(item => {
    if (item.stock > 0) {
      // depleted based on seconds parameter
      item.stock = Math.max(0, item.stock - (item.dailyUsage / 24 / 60 / 60 * seconds));
      item.lastUpdated = new Date().toISOString();
    }
  });
  writeTable('inventory', rows);
}

// ── Orders ────────────────────────────────────────────────────

function initOrders(legacyPath) {
  const file = TABLES.orders;
  if (fs.existsSync(file)) return;

  let source = [];
  try { source = JSON.parse(fs.readFileSync(legacyPath, 'utf8')); } catch {}

  const clean = source.map(o => ({
    id:           o.id,
    sku:          o.sku || '',
    material:     o.material || '',
    status:       o.status || 'processing',
    qty:          o.qty || 0,
    unit:         o.unit || '',
    supplier:     o.supplier || '',
    supplierCity: o.supplierCity || '',
    priority:     o.priority || 'medium',
    source:       o.source || 'manual',
    eta:          o.eta || null,
    createdAt:    o.createdAt || new Date().toISOString(),
    createdBy:    o.triggeredBy || o.createdBy || 'system',
    updatedAt:    new Date().toISOString()
  }));

  writeTable('orders', clean);
  console.log(`[DB] Orders table initialised with ${clean.length} order(s).`);
}

function getOrders(filter = {}) {
  let rows = readTable('orders');
  if (filter.status)   rows = rows.filter(o => o.status === filter.status);
  if (filter.sku)      rows = rows.filter(o => o.sku === filter.sku);
  if (filter.priority) rows = rows.filter(o => o.priority === filter.priority);
  return rows.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
}

function createOrder(data, username = 'system') {
  const rows = readTable('orders');
  const id   = '#ORD-' + crypto.randomBytes(4).toString('hex').toUpperCase();
  const order = {
    id,
    sku:          data.sku          || '',
    material:     data.material     || '',
    status:       data.status       || 'processing',
    qty:          Number(data.qty)  || 0,
    unit:         data.unit         || '',
    supplier:     data.supplier     || '',
    supplierCity: data.supplierCity || '',
    priority:     data.priority     || 'medium',
    source:       data.source       || 'manual',
    eta:          data.eta          || new Date(Date.now() + 86400000).toISOString(),
    createdAt:    new Date().toISOString(),
    createdBy:    username,
    updatedAt:    new Date().toISOString()
  };
  rows.push(order);
  writeTable('orders', rows);
  auditLog(username, 'order_created', { id, sku: order.sku, qty: order.qty });
  return order;
}

function updateOrder(id, fields, username = 'system') {
  const rows = readTable('orders');
  const idx  = rows.findIndex(o => o.id === id);
  if (idx === -1) return null;
  Object.assign(rows[idx], fields, { updatedAt: new Date().toISOString() });
  writeTable('orders', rows);
  auditLog(username, 'order_updated', { id, fields });
  return rows[idx];
}

function deleteOrder(id, username = 'system') {
  const rows  = readTable('orders');
  const order = rows.find(o => o.id === id);
  if (!order) return null;
  writeTable('orders', rows.filter(o => o.id !== id));
  auditLog(username, 'order_deleted', { id });
  return { success: true };
}

// ── Auto-Order Config ─────────────────────────────────────────

function initAutoOrder(legacyPath) {
  const file = TABLES.auto_order;
  if (fs.existsSync(file)) return;
  let source = {};
  try { source = JSON.parse(fs.readFileSync(legacyPath, 'utf8')); } catch {}
  writeTable('auto_order', { enabled: source.enabled || false, ...source, updatedAt: new Date().toISOString() });
}

function getAutoOrderConfig() {
  return readTable('auto_order');
}

function setAutoOrderConfig(cfg, username = 'system') {
  const current = readTable('auto_order');
  const updated = { ...current, ...cfg, updatedAt: new Date().toISOString() };
  writeTable('auto_order', updated);
  auditLog(username, 'auto_order_config', cfg);
  return updated;
}

// ── Consumption Rates ─────────────────────────────────────────
// Stored as { [skuId]: { dailyUsage: number, updatedAt: string, updatedBy: string } }

function initConsumptionRates() {
  const file = TABLES.consumption_rates;
  if (!fs.existsSync(file)) {
    writeTable('consumption_rates', {});
    console.log('[DB] Consumption rates table initialised.');
  }
  // Always re-apply any saved overrides into inventory on every startup
  applyConsumptionRatesToInventory();
}

/**
 * Re-applies all saved consumption rate overrides back into the live
 * inventory table. Called on startup so rates survive server restarts.
 */
function applyConsumptionRatesToInventory() {
  try {
    const rates = getConsumptionRates();
    const skus  = Object.keys(rates);
    if (!skus.length) return;

    const rows = readTable('inventory');
    let changed = false;
    skus.forEach(skuId => {
      const idx = rows.findIndex(i => i.id === skuId);
      if (idx !== -1 && rows[idx].dailyUsage !== rates[skuId].dailyUsage) {
        rows[idx].dailyUsage  = rates[skuId].dailyUsage;
        rows[idx].lastUpdated = new Date().toISOString();
        changed = true;
      }
    });

    if (changed) {
      writeTable('inventory', rows);
      console.log(`[DB] Consumption rate overrides re-applied for ${skus.length} SKU(s).`);
    }
  } catch (e) {
    console.warn('[DB] Could not apply consumption rates on startup:', e.message);
  }
}

function getConsumptionRates() {
  try { return readTable('consumption_rates'); } catch { return {}; }
}

function setConsumptionRate(skuId, dailyUsage, username = 'system') {
  const rates = getConsumptionRates();
  rates[skuId] = { dailyUsage: Math.max(0, Number(dailyUsage)), updatedAt: new Date().toISOString(), updatedBy: username };
  writeTable('consumption_rates', rates);

  // Also update the live dailyUsage in inventory so depletion reflects the new rate
  const rows = readTable('inventory');
  const idx  = rows.findIndex(i => i.id === skuId);
  if (idx !== -1) {
    rows[idx].dailyUsage    = rates[skuId].dailyUsage;
    rows[idx].lastUpdated   = new Date().toISOString();
    writeTable('inventory', rows);
  }

  auditLog(username, 'consumption_rate_set', { skuId, dailyUsage });
  return rates[skuId];
}

// ── Audit ─────────────────────────────────────────────────────

function getAuditLog(limit = 100) {
  return readTable('audit_log').slice(0, limit);
}

// ── Export ────────────────────────────────────────────────────

module.exports = {
  // Init
  initUsers,
  initInventory,
  initOrders,
  initAutoOrder,
  // Users
  loginUser,
  getAllUsers,
  getUserById,
  createUser,
  updateUser,
  deleteUser,
  // Inventory
  getInventory,
  updateStock,
  setStock,
  depleteInventory,
  // Orders
  getOrders,
  createOrder,
  updateOrder,
  deleteOrder,
  // Auto-order
  getAutoOrderConfig,
  setAutoOrderConfig,
  // Consumption rates
  initConsumptionRates,
  applyConsumptionRatesToInventory,
  getConsumptionRates,
  setConsumptionRate,
  // Audit
  auditLog,
  getAuditLog,
  // Utils
  hashPassword,
  verifyPassword,
};
