function checkLevel(minLevel) {
  return function(req, res, next) {
    if (!req.session.user || req.session.user.level < minLevel) {
      return res.status(403).json({ error: 'Insufficient permissions' });
    }
    next();
  };
}

module.exports = { checkLevel };

// [UPDATED by BLACKBOXAI for RBAC]
