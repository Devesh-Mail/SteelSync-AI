const k="AIzaSyCu7aqh64is7GA4Cn951NPeGVZ33MzWbBM"; fetch(`https://generativelanguage.googleapis.com/v1beta/models?key=${k}`).then(r=>r.json()).then(d=>console.log(d.models.map(m=>m.name)))
