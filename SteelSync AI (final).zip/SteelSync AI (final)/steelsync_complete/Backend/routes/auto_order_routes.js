const express  = require('express');
const router   = express.Router();
const db       = require('../db/database');
const security = require('../db/security');

router.get('/', (req, res) => {
  res.json(db.getAutoOrderConfig());
});

router.put('/', security.requireLevel(2), (req, res) => {
  try {
    const cfg = db.setAutoOrderConfig(req.body, req.session.user.username);
    res.json(cfg);
  } catch (e) { res.status(400).json({ error: e.message }); }
});

// Trigger auto order check manually (L2+)
router.post('/check', security.requireLevel(2), (req, res) => {
  try {
    const cfg       = db.getAutoOrderConfig();
    if (!cfg.systemEnabled && !cfg.enabled) return res.json({ triggered: [], reason: 'Auto-order is disabled' });
    const inventory = db.getInventory();
    const triggered = [];
    inventory.forEach(item => {
      if (item.stock < item.reorderThreshold) {
        const order = db.createOrder({
          sku:      item.id,
          material: item.material,
          qty:      item.reorderThreshold * 2,
          unit:     item.unit,
          supplier: item.supplierName,
          supplierCity: item.supplierCity,
          priority: item.stock <= 0 ? 'critical' : 'high',
          source:   'auto',
          eta:      new Date(Date.now() + 86400000).toISOString()
        }, 'auto-order-system');
        triggered.push(order);
      }
    });
    res.json({ triggered: triggered, orders: triggered });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

module.exports = router;
