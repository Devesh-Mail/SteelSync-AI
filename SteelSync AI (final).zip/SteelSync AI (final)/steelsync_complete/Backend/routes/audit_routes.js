const express = require('express');
const router  = express.Router();
const db      = require('../db/database');

// GET /audit?limit=100
router.get('/', (req, res) => {
  const limit = Math.min(parseInt(req.query.limit) || 100, 500);
  res.json(db.getAuditLog(limit));
});

module.exports = router;
