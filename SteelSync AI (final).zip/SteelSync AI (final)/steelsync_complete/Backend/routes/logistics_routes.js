const express = require('express');
const axios = require('axios');
const router = express.Router();

router.get(/(.*)/, async (req, res) => {
  try {
    const urlSuffix = req.url;
    const targetUrl = `https://railradar.trainsatlas.com/api${urlSuffix}`;
    
    const apiKey = req.headers['x-api-key'] || 'rr_s346wux4qjcig6k76k6j6g1bf6ltasna';
    
    // Some headers from client might be unnecessary or problematic, so we just forward these
    const response = await axios.get(targetUrl, {
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'x-api-key': apiKey,
        'Accept': 'application/json'
      }
    });

    res.json(response.data);
  } catch (error) {
    console.error(`Logistics Proxy Error for ${req.url}:`, error.message);
    res.status(error.response?.status || 500).json(error.response?.data || { error: 'Proxy request failed' });
  }
});

module.exports = router;
