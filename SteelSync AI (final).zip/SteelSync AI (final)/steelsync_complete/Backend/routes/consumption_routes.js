const express  = require('express');
const router   = express.Router();
const db       = require('../db/database');
const security = require('../db/security');

// GET all consumption rates
router.get('/', (req, res) => {
  res.json(db.getConsumptionRates());
});

// PUT update a single SKU's consumption rate (Level 2+)
router.put('/:skuId', security.requireLevel(2), (req, res) => {
  try {
    const { skuId } = req.params;
    const { dailyUsage } = req.body;
    if (dailyUsage === undefined || isNaN(Number(dailyUsage))) {
      return res.status(400).json({ error: 'dailyUsage must be a number' });
    }
    const result = db.setConsumptionRate(skuId, dailyUsage, req.session.user.username);
    res.json({ skuId, ...result });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// PUT bulk-update all consumption rates in one call (Level 2+)
// Body: { rates: { "SKU-1001": 300, "SKU-1002": 200, ... } }
router.put('/', security.requireLevel(2), (req, res) => {
  try {
    const { rates } = req.body;
    if (!rates || typeof rates !== 'object') {
      return res.status(400).json({ error: 'body must contain a "rates" object' });
    }
    const results = {};
    for (const [skuId, dailyUsage] of Object.entries(rates)) {
      if (!isNaN(Number(dailyUsage))) {
        results[skuId] = db.setConsumptionRate(skuId, dailyUsage, req.session.user.username);
      }
    }
    res.json({ updated: Object.keys(results).length, results });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

module.exports = router;
