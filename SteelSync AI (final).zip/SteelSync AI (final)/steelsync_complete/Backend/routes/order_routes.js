const express  = require('express');
const router   = express.Router();
const db       = require('../db/database');
const security = require('../db/security');

// GET /orders
router.get('/', (req, res) => {
  try { res.json(db.getOrders(req.query)); }
  catch (e) { res.status(500).json({ error: e.message }); }
});

// GET /orders/:id
router.get('/:id', (req, res) => {
  const orders = db.getOrders();
  const order  = orders.find(o => o.id === decodeURIComponent(req.params.id));
  if (order) res.json(order);
  else res.status(404).json({ error: 'Order not found' });
});

// POST /orders — create (L2+)
router.post('/', security.requireLevel(2), (req, res) => {
  try {
    const order = db.createOrder(req.body, req.session.user.username);
    res.status(201).json(order);
  } catch (e) { res.status(400).json({ error: e.message }); }
});

// PUT /orders/:id — update status (L2+)
router.put('/:id', security.requireLevel(2), (req, res) => {
  try {
    const order = db.updateOrder(decodeURIComponent(req.params.id), req.body, req.session.user.username);
    if (order) res.json(order);
    else res.status(404).json({ error: 'Order not found' });
  } catch (e) { res.status(400).json({ error: e.message }); }
});

// DELETE /orders/:id — admin only
router.delete('/:id', security.requireLevel(3), (req, res) => {
  try {
    const result = db.deleteOrder(decodeURIComponent(req.params.id), req.session.user.username);
    if (result) res.json(result);
    else res.status(404).json({ error: 'Order not found' });
  } catch (e) { res.status(400).json({ error: e.message }); }
});

module.exports = router;
