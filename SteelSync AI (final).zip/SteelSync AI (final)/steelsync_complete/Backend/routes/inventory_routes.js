const express  = require('express');
const router   = express.Router();
const db       = require('../db/database');
const security = require('../db/security');

// GET /inventory — all items with computed fields
router.get('/', (req, res) => {
  try { res.json(db.getInventory()); }
  catch (e) { res.status(500).json({ error: e.message }); }
});

// GET /inventory/:id
router.get('/:id', (req, res) => {
  const list = db.getInventory();
  const item = list.find(i => i.id === req.params.id);
  if (item) res.json(item);
  else res.status(404).json({ error: 'SKU not found' });
});

// POST /inventory/update — adjust stock by delta (L2+)
router.post('/update', security.requireLevel(2), (req, res) => {
  const { id, delta } = req.body;
  if (!id || delta === undefined)
    return res.status(400).json({ error: 'id and delta are required' });
  const item = db.updateStock(id, Number(delta), req.session.user.username);
  if (item) res.json({ ...item, daysLeft: item.dailyUsage > 0 ? Math.max(0, +(item.stock/item.dailyUsage).toFixed(1)) : 0 });
  else res.status(404).json({ error: 'Item not found' });
});

// POST /inventory/set — set stock directly (L3 admin)
router.post('/set', security.requireLevel(3), (req, res) => {
  const { id, value } = req.body;
  if (!id || value === undefined)
    return res.status(400).json({ error: 'id and value are required' });
  const item = db.setStock(id, Number(value), req.session.user.username);
  if (item) res.json(item);
  else res.status(404).json({ error: 'Item not found' });
});

module.exports = router;
