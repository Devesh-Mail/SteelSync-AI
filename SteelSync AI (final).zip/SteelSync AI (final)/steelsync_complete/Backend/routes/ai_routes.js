const express = require("express")
const router = express.Router()

const riskService = require("../services/risk_service")
const costService = require("../services/cost_service")
const shutdownService = require("../services/shutdown_service")

router.get("/risk",(req,res)=>{
    res.json(riskService.predictRisk())
})

router.get("/cost",(req,res)=>{
    res.json(costService.optimizeCost())
})

router.get("/shutdown",(req,res)=>{
    res.json(shutdownService.predictShutdown())
})

router.post("/gemini", async (req, res) => {
    try {
        const { contents, modelIdx } = req.body;
        const GEMINI_API_KEY = process.env.GEMINI_API_KEY || 'AIzaSyCu7aqh64is7GA4Cn951NPeGVZ33MzWbBM';
        const GEMINI_MODELS = [
          'gemini-2.5-flash',
          'gemini-2.0-flash',
          'gemini-flash-latest'
        ];
        const model = GEMINI_MODELS[modelIdx || 0] || 'gemini-2.5-flash';
        const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${GEMINI_API_KEY}`;
        
        const response = await fetch(url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              contents,
              generationConfig: { temperature: 0.65, maxOutputTokens: 350 }
            })
        });
        
        if (!response.ok) {
            const errText = await response.text();
            let errData = {};
            try { errData = JSON.parse(errText); } catch(e){}
            return res.status(response.status).json({ error: errData.error?.message || `API error ${response.status}` });
        }
        const data = await response.json();
        res.json(data);
    } catch (error) {
        console.error("Gemini API Error:", error);
        res.status(500).json({ error: "Failed to communicate with AI Engine" });
    }
});

module.exports = router