const express  = require('express');
const router   = express.Router();
const db       = require('../db/database');
const security = require('../db/security');

// Stricter rate limit for auth: 10 req/min per IP
const authLimit = security.createRateLimiter(10, 60000);

// POST /auth/login
router.post('/login', authLimit, (req, res) => {
  const ip = req.ip || req.socket.remoteAddress;
  const { username, password } = req.body;

  if (!username || !password)
    return res.status(400).json({ success: false, error: 'Username and password are required' });

  // Brute-force protection
  const lockSecs = security.isLoginLocked(ip);
  if (lockSecs)
    return res.status(429).json({ success: false, error: `Account locked. Try again in ${lockSecs}s.` });

  const user = db.loginUser(username.trim(), password);

  if (!user) {
    security.trackLoginAttempt(ip, false);
    return res.status(401).json({ success: false, error: 'Invalid credentials' });
  }

  security.trackLoginAttempt(ip, true);
  req.session.regenerate((err) => {
    if (err) return res.status(500).json({ success: false, error: 'Session error' });
    req.session.user = { id: user.id, username: user.username, level: user.level, role: user.role };
    db.auditLog(user.username, 'login', { ip });
    res.json({ success: true, level: user.level, role: user.role, username: user.username, fullName: user.fullName });
  });
});

// GET /auth/me
router.get('/me', (req, res) => {
  if (req.session.user) res.json({ loggedIn: true, ...req.session.user });
  else res.status(401).json({ loggedIn: false });
});

// POST /auth/logout
router.post('/logout', (req, res) => {
  const u = req.session.user;
  if (u) db.auditLog(u.username, 'logout', {});
  req.session.destroy(() => res.json({ success: true }));
});

// GET /auth/users (admin)
router.get('/users', security.requireLevel(3), (req, res) => {
  try { res.json(db.getAllUsers()); }
  catch (e) { res.status(500).json({ error: e.message }); }
});

// POST /auth/users (admin)
router.post('/users', security.requireLevel(3), (req, res) => {
  try {
    const user = db.createUser(req.body);
    db.auditLog(req.session.user.username, 'create_user', { username: req.body.username });
    res.status(201).json(user);
  } catch (e) { res.status(400).json({ error: e.message }); }
});

// PUT /auth/users/:id (admin)
router.put('/users/:id', security.requireLevel(3), (req, res) => {
  try {
    const user = db.updateUser(Number(req.params.id), req.body);
    db.auditLog(req.session.user.username, 'update_user', { id: req.params.id });
    res.json(user);
  } catch (e) { res.status(400).json({ error: e.message }); }
});

// DELETE /auth/users/:id (admin)
router.delete('/users/:id', security.requireLevel(3), (req, res) => {
  try {
    db.auditLog(req.session.user.username, 'delete_user', { id: req.params.id });
    res.json(db.deleteUser(Number(req.params.id)));
  } catch (e) { res.status(400).json({ error: e.message }); }
});

module.exports = router;
