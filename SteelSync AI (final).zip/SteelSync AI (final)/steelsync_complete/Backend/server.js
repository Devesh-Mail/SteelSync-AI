/**
 * NexusOps Backend Server — v2 with Secure Database
 */
const express      = require('express');
const session      = require('express-session');
const cors         = require('cors');
const MemoryStore  = require('memorystore')(session);
const path         = require('path');
const crypto       = require('crypto');

// Database & Security
const db       = require('./db/database');
const security = require('./db/security');

// Routes
const inventoryRoutes  = require('./routes/inventory_routes');
const orderRoutes      = require('./routes/order_routes');
const aiRoutes         = require('./routes/ai_routes');
const authRoutes       = require('./routes/auth_routes');
const autoOrderRoutes  = require('./routes/auto_order_routes');
const consumptionRoutes = require('./routes/consumption_routes');
const auditRoutes       = require('./routes/audit_routes');
const logisticsRoutes   = require('./routes/logistics_routes');

// Initialise DB tables from legacy JSON
db.initUsers(     path.join(__dirname, 'data/users_db.json'));
db.initInventory( path.join(__dirname, 'data/inventory_data_real.json'));
db.initOrders(    path.join(__dirname, 'data/orders_data_real.json'));
db.initAutoOrder( path.join(__dirname, 'data/auto_order_config.json'));
db.initConsumptionRates();

const app = express();

app.use(security.securityHeaders);
app.use(cors({ credentials: true, origin: (o, cb) => cb(null, true) }));
app.use(express.json({ limit: '1mb' }));
app.use(security.sanitizeBody);
app.use(security.createRateLimiter(120, 60000));

const SESSION_SECRET = process.env.SESSION_SECRET || crypto.randomBytes(32).toString('hex');

app.use(session({
  secret: SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  store: new MemoryStore({ checkPeriod: 86400000 }),
  name: 'nexusops.sid',
  cookie: {
    secure:   process.env.NODE_ENV === 'production',
    httpOnly: true,
    sameSite: 'lax',
    maxAge:   8 * 60 * 60 * 1000
  }
}));

// Fallback for file:/// testing
app.use((req, res, next) => {
  if (!req.session) req.session = {};
  if (!req.session.user && req.headers['x-level']) {
    req.session.user = {
      level:    parseInt(req.headers['x-level'], 10) || 1,
      username: req.headers['x-user'] || 'guest',
      role:     parseInt(req.headers['x-level'], 10) >= 3 ? 'Admin' : 'Operator'
    };
  }
  next();
});

app.use('/auth',       authRoutes);
app.use('/inventory',  security.requireLevel(1), inventoryRoutes);
app.use('/orders',     security.requireLevel(1), orderRoutes);
app.use('/ai',         security.requireLevel(1), aiRoutes);
app.use('/auto-order',   security.requireLevel(1), autoOrderRoutes);
app.use('/consumption',  security.requireLevel(1), consumptionRoutes);
app.use('/audit',        security.requireLevel(3), auditRoutes);
app.use('/logistics',    security.requireLevel(1), logisticsRoutes);

app.get('/health', (req, res) =>
  res.json({ status: 'ok', time: new Date().toISOString(), db: 'secure-json-db' })
);

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log('\n✅  NexusOps running on port ' + PORT);
  console.log('🔐  DB: Secure JSON + PBKDF2 hashed passwords');
  console.log('👤  admin/enter (L3)  |  op/op123 (L2)  |  user/user123 (L1)\n');
});

const cron = require('node-cron');
cron.schedule('* * * * *', () => { db.depleteInventory(60); });
