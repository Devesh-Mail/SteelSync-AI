const db = require('../db/database');

function loadInventory() {
  return db.getInventory();
}

function predictRisk() {
  const inventory = loadInventory();
  return inventory.map(item => {
    const daysRemaining = item.stock / item.dailyUsage;
    let risk = "LOW";
    let score = 0;
    if (daysRemaining < 2) {
      risk = "CRITICAL";
      score = 90 + Math.random() * 10;
    } else if (daysRemaining < 5) {
      risk = "MEDIUM";
      score = 50 + Math.random() * 30;
    } else if (daysRemaining < 10) {
      risk = "LOW";
      score = 10 + Math.random() * 20;
    }
    return {
      id: item.id,
      material: item.material,
      daysRemaining: daysRemaining.toFixed(1),
      riskLevel: risk,
      riskScore,
      mitigation: risk === "CRITICAL" ? "Immediate reorder" : "Monitor"
    };
  }).sort((a, b) => b.riskScore - a.riskScore);  // highest risk first
}

module.exports = { predictRisk };

// [UPDATED by BLACKBOXAI for robust risk]
