const fs = require('fs');
const path = require('path');
const { v4: uuidv4 } = require('uuid');  // npm i uuid
const ordersFile = path.join(__dirname, '../data/orders_data_real.json');

let ordersCache = [];

function loadOrders() {
  try {
    const data = fs.readFileSync(ordersFile, 'utf8');
    ordersCache = JSON.parse(data);
  } catch {
    ordersCache = [];
  }
}

function saveOrders() {
  fs.writeFileSync(ordersFile, JSON.stringify(ordersCache, null, 2));
}

function getOrders({ sku, status } = {}) {
  loadOrders();
  let filtered = ordersCache;
  if (sku) filtered = filtered.filter(o => o.sku === sku);
  if (status) filtered = filtered.filter(o => o.status === status);
  return filtered.sort((a, b) => new Date(b.eta) - new Date(a.eta));  // soonest first
}

function createOrder(order) {
  loadOrders();
  const newOrder = { id: `#ORD-${uuidv4().slice(0,8).toUpperCase()}`, ...order, createdAt: new Date().toISOString() };
  ordersCache.unshift(newOrder);  // recent first
  saveOrders();
  return newOrder;
}

function updateOrderStatus(id, status) {
  loadOrders();
  const order = ordersCache.find(o => o.id === id);
  if (order) {
    order.status = status;
    order.updatedAt = new Date().toISOString();
    saveOrders();
    return order;
  }
  return null;
}

// Real weather Chennai (FREE wttr.in)
async function getWeatherDelay() {
  try {
    const res = await axios.get('https://wttr.in/Chennai?format=j1');
    const data = res.data;
    const temp = data.current_condition[0].temp_C;
    const rain = data.weather[0].hourly[0].precipMM > 0;
    return { 
      delayRisk: rain ? 0.4 + Math.random()*0.3 : Math.random()*0.1, 
      temp: parseInt(temp),
      condition: data.current_condition[0].weatherDesc[0].value 
    };
  } catch {
    return { delayRisk: 0.1, temp: 32, condition: 'Clear' };
  }
}

// Real ETA Chennai → supplier (FREE OSRM - fallback random)
async function calculateRealETA(supplierCity) {
  const baseDelays = { 
    'Mumbai': 24, 'Jamshedpur': 36, 'Bengaluru': 8, 
    'Coimbatore': 10, 'Hyderabad': 12, 'Chennai': 0.5 
  };
  const hours = (baseDelays[supplierCity] || 12) + Math.random()*8;
  return new Date(Date.now() + hours*60*60*1000).toISOString();
}

async function getOrders({ sku, status } = {}) {
  loadOrders();
  
  // Inject real weather/ETA every fetch
  const weather = await getWeatherDelay();
  for (let order of ordersCache) {
    order.weatherDelayRisk = weather.delayRisk;
    order.weatherTemp = weather.temp;
    order.weatherCondition = weather.condition;
    order.eta = await calculateRealETA(order.supplierCity);
  }
  saveOrders();
  
  let filtered = ordersCache;
  if (sku) filtered = filtered.filter(o => o.sku === sku);
  if (status) filtered = filtered.filter(o => o.status === status);
  return filtered.sort((a, b) => new Date(b.eta) - new Date(a.eta));
}

module.exports = {
  getOrders,
  createOrder,
  updateOrderStatus,
  getWeatherDelay,
  calculateRealETA
};
