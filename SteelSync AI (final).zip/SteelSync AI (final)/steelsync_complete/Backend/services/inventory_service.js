const fs = require('fs');
const path = require('path');
const axios = require('axios');  // npm i axios
const inventoryFile = path.join(__dirname, '../data/inventory_data_real.json');

let inventoryCache = [];

function loadInventory() {
  try {
    const data = fs.readFileSync(inventoryFile, 'utf8');
    inventoryCache = JSON.parse(data);
  } catch (e) {
    inventoryCache = require(inventoryFile);  // fallback
  }
  return inventoryCache;
}

function saveInventory() {
  fs.writeFileSync(inventoryFile, JSON.stringify(inventoryCache, null, 2));
}

function getInventory() {
  loadInventory();
  return inventoryCache.map(item => ({
    ...item,
    daysLeft: Math.max(0, (item.stock / item.dailyUsage).toFixed(1)),
    pctStock: ((item.stock / item.maxStock) * 100).toFixed(1),
    riskPct: item.stock < item.reorderThreshold ? ((item.reorderThreshold - item.stock) / item.reorderThreshold * 100).toFixed(1) : 0
  }));
}

function updateStock(id, delta) {
  loadInventory();
  const item = inventoryCache.find(i => i.id === id);
  if (item) {
    item.stock = Math.max(0, item.stock + delta);
    saveInventory();
    return item;
  }
  return null;
}

// Realtime depletion sim (call from cron)
function depleteInventory() {
  loadInventory();
  inventoryCache.forEach(item => {
    if (item.stock > 0) {
      item.stock -= (item.dailyUsage / 24 / 60 / 60 * 1000 * 5);  // sim 5s tick for demo
    }
  });
  saveInventory();
}

// Mock weather API for delays
async function getWeatherDelay(sku) {
  // Placeholder: sk_OPENWEATHER
  try {
    // await axios.get('https://api.openweathermap.org/data/2.5/weather?q=Chennai&appid=sk_placeholder');
    return { delayRisk: Math.random() > 0.8 ? 0.3 : 0, temp: 32 };  // mock
  } catch {
    return { delayRisk: 0.1 };
  }
}

module.exports = {
  getInventory,
  updateStock,
  depleteInventory,
  getWeatherDelay
};

// [UPDATED by BLACKBOXAI for realtime + robust calcs]
