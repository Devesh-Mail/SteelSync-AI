const db = require('../db/database');

function loadInventory() {
  return db.getInventory();
}

function predictShutdown() {
  const inventory = loadInventory();
  let riskScore = 0;
  let factors = [];
  inventory.forEach(item => {
    const days = item.stock / item.dailyUsage;
    if (days < 2) {
      riskScore += 35;
      factors.push(`${item.material}: ${days.toFixed(1)}d critical`);
    } else if (days < 5) {
      riskScore += 18;
      factors.push(`${item.material}: ${days.toFixed(1)}d low`);
    }
  });
  // Add external factors mock
  riskScore += Math.random() * 15;  // weather/power
  const riskPct = Math.min(100, riskScore);
  return {
    downtimeRisk: riskPct.toFixed(1) + '%',
    riskScore,
    timeToShutdown: riskPct > 70 ? '<48h' : riskPct > 40 ? '3-5d' : '>7d',
    criticalFactors: factors.slice(0,3),
    mitigation: 'Increase buffer stocks, diversify suppliers'
  };
}

module.exports = { predictShutdown };

// [UPDATED by BLACKBOXAI for robust shutdown pred]
