const fs = require('fs');
const path = require('path');
const axios = require('axios');  // npm i axios

// Mock routes with fuel, delay factors
const ROUTES = [
  { route: "A-North", cost: 200000, fuel: 1200, delayRisk: 0.15, distance: 450 },
  { route: "B-East", cost: 150000, fuel: 950, delayRisk: 0.25, distance: 380 },
  { route: "C-South", cost: 170000, cost: 1100, delayRisk: 0.08, distance: 420 }
];

async function optimizeCost() {
  // Mock fuel price API
  const fuelPrice = 85.5;  // placeholder from API

  return ROUTES.map(r => ({
    ...r,
    totalCost: r.cost + (r.fuel * fuelPrice),
    costPerKm: (r.cost + r.fuel * fuelPrice) / r.distance,
    recommendation: r.delayRisk < 0.1 ? 'Primary' : 'Secondary'
  })).sort((a, b) => a.totalCost - b.totalCost)[0];  // best first
}

// Realtime cost adjust
function adjustCosts(fuelDelta) {
  ROUTES.forEach(r => {
    r.cost += fuelDelta * r.fuel * 0.01;  // 1% per unit
  });
}

module.exports = { optimizeCost, adjustCosts };

// [UPDATED by BLACKBOXAI for robust cost opt + APIs]
