const fs   = require('fs');
const path = require('path');
const { v4: uuidv4 } = require('uuid');

const configFile    = path.join(__dirname, '../data/auto_order_config.json');
const ordersFile    = path.join(__dirname, '../data/orders_data_real.json');
const inventoryFile = path.join(__dirname, '../data/inventory_data_real.json');

// ── File helpers ───────────────────────────────────────────────────────────────

function loadConfig() {
  try { return JSON.parse(fs.readFileSync(configFile, 'utf8')); }
  catch { return { systemEnabled: false, globalSettings: {}, skuRules: [] }; }
}

function saveConfig(config) {
  fs.writeFileSync(configFile, JSON.stringify(config, null, 2));
}

function loadOrders() {
  try { return JSON.parse(fs.readFileSync(ordersFile, 'utf8')); }
  catch { return []; }
}

function saveOrders(orders) {
  fs.writeFileSync(ordersFile, JSON.stringify(orders, null, 2));
}

function loadInventory() {
  try { return JSON.parse(fs.readFileSync(inventoryFile, 'utf8')); }
  catch { return []; }
}

// Strip display-only fields before persisting to DB (Fix 4)
function sanitiseSkuRules(rules) {
  return (rules || []).map(rule => {
    const { currentStock, maxStock, ...clean } = rule; // remove transient fields
    return clean;
  });
}

// ── GET /auto-order/config ─────────────────────────────────────────────────────
function getConfig(req, res) {
  const config    = loadConfig();
  const inventory = loadInventory();

  // Enrich skuRules with live stock for display — NOT saved back to DB
  const enriched = config.skuRules.map(rule => {
    const inv = inventory.find(i => i.id === rule.id);
    return {
      ...rule,
      currentStock: inv ? Math.max(0, Math.round(inv.stock)) : 0,
      maxStock:     inv ? inv.maxStock : 0,
    };
  });

  res.json({ ...config, skuRules: enriched });
}

// ── PUT /auto-order/config — save full config ──────────────────────────────────
function saveSettings(req, res) {
  // Enforce Level 2 for writes
  if (!req.session.user || req.session.user.level < 2) {
    return res.status(403).json({ error: 'Level 2 or above required to save settings.' });
  }

  const config = loadConfig();
  const { globalSettings, skuRules, systemEnabled } = req.body;

  if (typeof systemEnabled === 'boolean') config.systemEnabled = systemEnabled;
  if (globalSettings) config.globalSettings = { ...config.globalSettings, ...globalSettings };

  // FIX 4: strip currentStock/maxStock before writing to file
  if (skuRules) config.skuRules = sanitiseSkuRules(skuRules);

  config.updatedAt = new Date().toISOString();
  config.updatedBy = req.session.user.username || 'operator';

  saveConfig(config);

  // Return config enriched with live stock so the page can re-render immediately
  const inventory = loadInventory();
  const enriched  = config.skuRules.map(rule => {
    const inv = inventory.find(i => i.id === rule.id);
    return { ...rule, currentStock: inv ? Math.max(0, Math.round(inv.stock)) : 0, maxStock: inv ? inv.maxStock : 0 };
  });

  res.json({ success: true, config: { ...config, skuRules: enriched } });
}

// ── PATCH /auto-order/toggle — flip systemEnabled only ────────────────────────
function toggleSystem(req, res) {
  if (!req.session.user || req.session.user.level < 2) {
    return res.status(403).json({ error: 'Level 2 or above required.' });
  }

  const config = loadConfig();
  config.systemEnabled = !config.systemEnabled;
  config.updatedAt = new Date().toISOString();
  config.updatedBy = req.session.user.username || 'operator';
  saveConfig(config);

  res.json({ success: true, systemEnabled: config.systemEnabled });
}

// ── POST /auto-order/run — check inventory and fire orders ────────────────────
function runAutoOrder(req, res) {
  if (!req.session.user || req.session.user.level < 2) {
    return res.status(403).json({ error: 'Level 2 or above required.' });
  }

  const config    = loadConfig();
  const inventory = loadInventory();
  const orders    = loadOrders();

  if (!config.systemEnabled) {
    return res.json({ triggered: [], message: 'Auto-order system is disabled. Activate it first.' });
  }

  const triggered = [];
  const now = new Date().toISOString();

  config.skuRules.forEach(rule => {
    if (!rule.autoOn) return;

    const inv = inventory.find(i => i.id === rule.id);
    if (!inv) return;

    const stock = Math.max(0, inv.stock);
    if (stock > rule.threshold) return; // still above threshold — no order needed

    // Cooldown: don't re-order within cooldownHours
    const cooldownMs = (config.globalSettings.cooldownHours || 24) * 3600 * 1000;
    if (rule.lastTriggered && (Date.now() - new Date(rule.lastTriggered).getTime()) < cooldownMs) return;

    const newOrder = {
      id:           `#ORD-${uuidv4().slice(0, 8).toUpperCase()}`,
      sku:          rule.id,
      material:     rule.name,
      status:       'processing',
      qty:          rule.orderQty,
      unit:         rule.unit,
      supplier:     rule.supplier,
      supplierCity: rule.supplierCity,
      priority:     stock <= rule.threshold * 0.5 ? 'critical' : 'high',
      source:       'auto',
      eta:          new Date(Date.now() + 24 * 3600 * 1000).toISOString(),
      createdAt:    now,
      triggeredBy:  'auto-order-system',
    };

    orders.unshift(newOrder);
    rule.lastTriggered = now;
    triggered.push(newOrder);
  });

  if (triggered.length > 0) {
    saveOrders(orders);
    saveConfig(config); // persist updated lastTriggered timestamps
  }

  res.json({ triggered, count: triggered.length });
}

// ── GET /auto-order/status — lightweight widget for other pages ───────────────
function getStatus(req, res) {
  const config    = loadConfig();
  const inventory = loadInventory();
  const orders    = loadOrders();

  const autoOrders     = orders.filter(o => o.source === 'auto');
  const belowThreshold = config.skuRules.filter(rule => {
    const inv = inventory.find(i => i.id === rule.id);
    return inv && Math.max(0, inv.stock) <= rule.threshold && rule.autoOn;
  });

  res.json({
    systemEnabled:     config.systemEnabled,
    updatedAt:         config.updatedAt,
    updatedBy:         config.updatedBy,
    skuCount:          config.skuRules.length,
    activeRules:       config.skuRules.filter(r => r.autoOn).length,
    belowThreshold:    belowThreshold.length,
    autoOrdersTotal:   autoOrders.length,
    autoOrdersPending: autoOrders.filter(o => o.status === 'processing').length,
  });
}

module.exports = { getConfig, saveSettings, toggleSystem, runAutoOrder, getStatus };
