/**
 * NexusOps User Database Service
 * Stores users in data/users_db.json with SHA-256 hashed passwords.
 * Authority levels: 1 = Read-only, 2 = Operator, 3 = Admin (full authority)
 */

const fs     = require('fs');
const path   = require('path');
const crypto = require('crypto'); // Built-in Node.js — no install needed

const DB_PATH = path.join(__dirname, '../data/users_db.json');

// ── Helpers ───────────────────────────────────────────────────────────────────

function hashPassword(plain) {
  return crypto.createHash('sha256').update(plain).digest('hex');
}

function readDB() {
  const raw = fs.readFileSync(DB_PATH, 'utf8');
  return JSON.parse(raw);
}

function writeDB(db) {
  db._meta.lastModified = new Date().toISOString();
  fs.writeFileSync(DB_PATH, JSON.stringify(db, null, 2), 'utf8');
}

// ── Initialise: hash any plain passwords on first boot ────────────────────────

function initDB() {
  const db = readDB();
  let changed = false;

  db.users = db.users.map(u => {
    if (u.password_plain) {
      u.passwordHash = hashPassword(u.password_plain);
      delete u.password_plain;
      changed = true;
    }
    return u;
  });

  if (changed) writeDB(db);
  console.log(`[UserDB] Loaded ${db.users.length} user(s) from ${DB_PATH}`);
}

// ── Public API ────────────────────────────────────────────────────────────────

/** Verify credentials. Returns safe user object on success, or null. */
function verifyUser(username, password) {
  const db   = readDB();
  const hash = hashPassword(password);
  const user = db.users.find(
    u => u.username === username && u.passwordHash === hash && u.active
  );
  if (!user) return null;

  user.lastLogin = new Date().toISOString();
  writeDB(db);

  const { passwordHash, ...safe } = user;
  return safe;
}

/** Get all users — no passwords. */
function getAllUsers() {
  const db = readDB();
  return db.users.map(({ passwordHash, password_plain, ...u }) => u);
}

/** Get single user by id — no password. */
function getUserById(id) {
  const db   = readDB();
  const user = db.users.find(u => u.id === id);
  if (!user) return null;
  const { passwordHash, password_plain, ...safe } = user;
  return safe;
}

/** Create a new user. Throws on duplicate username. */
function createUser({ username, password, level, role, fullName, email }) {
  const db = readDB();
  if (db.users.find(u => u.username === username)) {
    throw new Error(`Username "${username}" already exists`);
  }
  const maxId   = db.users.reduce((m, u) => Math.max(m, u.id), 0);
  const lvl     = Number(level) || 1;
  const newUser = {
    id: maxId + 1,
    username,
    passwordHash: hashPassword(password),
    level: lvl,
    role: role || (lvl === 3 ? 'Admin' : lvl === 2 ? 'Operator' : 'Read-Only'),
    fullName: fullName || username,
    email:    email    || '',
    createdAt: new Date().toISOString(),
    lastLogin: null,
    active: true
  };
  db.users.push(newUser);
  writeDB(db);
  const { passwordHash, ...safe } = newUser;
  return safe;
}

/** Update a user's fields. Pass { password } to change password. */
function updateUser(id, fields) {
  const db  = readDB();
  const idx = db.users.findIndex(u => u.id === id);
  if (idx === -1) throw new Error('User not found');
  if (fields.password) {
    db.users[idx].passwordHash = hashPassword(fields.password);
    delete fields.password;
  }
  Object.assign(db.users[idx], fields);
  writeDB(db);
  const { passwordHash, ...safe } = db.users[idx];
  return safe;
}

/** Soft-delete (deactivate) a user. Admin account is protected. */
function deleteUser(id) {
  const db  = readDB();
  const idx = db.users.findIndex(u => u.id === id);
  if (idx === -1) throw new Error('User not found');
  if (db.users[idx].username === 'admin') throw new Error('Cannot delete the admin account');
  db.users[idx].active = false;
  writeDB(db);
  return { success: true };
}

module.exports = { initDB, verifyUser, getAllUsers, getUserById, createUser, updateUser, deleteUser };
